#ifndef __TIM_H__
#define __TIM_H__

#include "stm32f4xx.h"

void TIM2_Init(void);
void TIM3_Init(void);
void TIM4_Init(void);

#endif
